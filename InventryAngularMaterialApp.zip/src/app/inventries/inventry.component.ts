import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './inventry.component.html',
  styleUrls: ['./inventry.component.css']
})
export class InventryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
