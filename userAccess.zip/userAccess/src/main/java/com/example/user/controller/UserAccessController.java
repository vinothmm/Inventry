package com.example.user.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.dto.ApiResponse;
import com.example.user.dto.Inventry;
import com.example.user.service.UserAccessService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserAccessController{

    @Autowired
    private UserAccessService userAccessService;
    
    @PostMapping(value = "/student/save" ,produces= "application/vnd.jcg.api.v1+json")
	public Inventry save(@Valid @RequestBody  Inventry student1) {
		System.out.println("Saving inventry details in the database."+
				userAccessService.findByRecord(student1.getsNo(), student1.getModel(), student1.getBrand()).isPresent());
		
		if(!userAccessService.findByRecord(student1.getsNo(), student1.getModel(), student1.getBrand()).isPresent()) {
		
			System.out.println("inside if ");
		return userAccessService.save(student1);
		
		}else {
			System.out.println("inside else ");
			return null;
		}
		
	}
    
    @PostMapping(value = "/student/saveinfo" ,produces= "application/vnd.jcg.api.v1+json")
    public ApiResponse getOne(@Valid @RequestBody  Inventry student1){
		
		if(!userAccessService.findByRecord(student1.getsNo(), student1.getModel(), student1.getBrand()).isPresent()) {
		
			System.out.println("inside if ");
			 return new ApiResponse(HttpStatus.OK.value(), "Inventry Created Successfully ",userAccessService.save(student1));
		
		}else {
			System.out.println("inside else ");
			return new ApiResponse(HttpStatus.ALREADY_REPORTED.value(), "Inventry duplicate ",null);
		}
       
    }
    
    

	// Get all students from the h2 database.
	// @GetMapping annotation handles the http get request matched with the given uri.
	@GetMapping(value= "/student/getall/{id}", produces= "application/vnd.jcg.api.v1+json")
	public Optional<Inventry> getAll(@PathVariable("id") int id) {
		System.out.println("Getting student details from the database.");
		return userAccessService.findById(id);
	}
	
	@GetMapping(value= "/student/getListall", produces= "application/vnd.jcg.api.v1+json")
	public List<Inventry> getAll() {
		System.out.println("Getting all inventry details from the database.");
		return userAccessService.findAll();
	}
	
	@GetMapping(value= "/student/delete/{sNo}", produces= "application/vnd.jcg.api.v1+json")
	public ApiResponse deleteRecord(@PathVariable("sNo") int sNo) {
		return new ApiResponse(HttpStatus.OK.value(), "Inventry Deleted Successfully ",userAccessService.deleteBysNo(sNo));
	}

}
