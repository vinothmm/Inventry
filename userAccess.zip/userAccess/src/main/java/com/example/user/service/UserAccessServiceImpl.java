package com.example.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.dto.Inventry;
import com.example.user.repo.UserRepository;

@Service
public class UserAccessServiceImpl implements UserAccessService{

	@Autowired
	UserRepository repository;
	
	 @PersistenceContext
		private EntityManager entityManager;

	@Override
	public Inventry save(Inventry student) {
		return repository.save(student);
	}

	public List<Inventry> getAll(int id) {
		final List<Inventry> students = new ArrayList<>();
		repository.findByInventoryIds(id);
		return students;
	}

	
	@Override
	public Optional<Inventry> findById(int id) {
		return repository.findById(id);
	}
	
	public int deleteBysNo(int sNo) {
		
		return repository.deleteBysNo(sNo);
	}

	@Override
	public List<Inventry> findAll() {
		return repository.findAll();
	}

	@Override
	public Optional<Inventry> findByRecord(int sNo, String model, String brand) {
		return repository.findByRecord(sNo,model,brand);
	}
}
