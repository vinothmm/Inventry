import { TestBed, inject } from '@angular/core/testing';

import { InventryServiceService } from './inventry-service.service';

describe('InventryServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InventryServiceService]
    });
  });

  it('should be created', inject([InventryServiceService], (service: InventryServiceService) => {
    expect(service).toBeTruthy();
  }));
});
