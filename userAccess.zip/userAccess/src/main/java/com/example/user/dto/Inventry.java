package com.example.user.dto;
 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name= "inventry")
public class Inventry {
	
	 	@Id
	    @Column(name="SNO")
	    private int sNo;
	    @Column(name="BRAND")
	    private String brand;
	    @Column(name="MODEL")
	    private String model;
	    @Column(name="STATUS")
	    private String status;
	    @Column(name="PURCHASEDATE")
	    private String dateOfPurchase;
	    
	    
		public int getsNo() {
			return sNo;
		}
		public void setsNo(int sNo) {
			this.sNo = sNo;
		}
		public String getBrand() {
			return brand;
		}
		public void setBrand(String brand) {
			this.brand = brand;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getDateOfPurchase() {
			return dateOfPurchase;
		}
		public void setDateOfPurchase(String dateOfPurchase) {
			this.dateOfPurchase = dateOfPurchase;
		}
		public Inventry(int sNo, String brand, String model, String status, String dateOfPurchase) {
			super();
			this.sNo = sNo;
			this.brand = brand;
			this.model = model;
			this.status = status;
			this.dateOfPurchase = dateOfPurchase;
		}
		public Inventry() {
			
		}
		@Override
		public String toString() {
			return "Inventry [sNo=" + sNo + ", brand=" + brand + ", model=" + model + ", status=" + status
					+ ", dateOfPurchase=" + dateOfPurchase + "]";
		}
	   
	    

}
