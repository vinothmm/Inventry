export class Inventry {
    sNo: number;
    brand: string;
    model: string;
    status: string;
    dateOfPurchase: string;
  }