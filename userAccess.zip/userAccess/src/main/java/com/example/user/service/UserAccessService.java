package com.example.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.example.user.dto.Inventry;
@Component
public interface UserAccessService {
		public Inventry save(Inventry student);
		public List<Inventry> getAll(int id);
		public List<Inventry> findAll();
		Optional<Inventry> findById(int id);
		Optional<Inventry> findByRecord(int sNo, String model,String brand);
		public int deleteBysNo(int sNo);
	 
}
