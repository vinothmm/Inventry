import { Component, OnInit,ViewChild, Input} from '@angular/core';
import { MatTableDataSource,MatSort,MatPaginator } from '@angular/material';
import { Inventry } from 'src/app/inventry';
import { InventryServiceService } from 'src/app/inventry-service.service';

export interface Data {
  operation: string;
  data: [string];
}

@Component({
  selector: 'app-inventry-list',
  templateUrl: './inventry-list.component.html',
  styleUrls: ['./inventry-list.component.css']
})
export class InventryListComponent implements OnInit {

    
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  k: number;
  @Input() searchable: boolean;
  inventry: Inventry = new Inventry();
  submitted = false;
  selectedRowIndex: number = -1;
  @Input() data: any;
  rowData: Data;
  isDuplicate = false;
  isSearchable: boolean;
  reportData: any;
  router: any; 
  constructor(private inventryServiceService: InventryServiceService,
    ) {
     } 
    dataList: Inventry[] = [];

    // listData = this.dataList;
   listData = new MatTableDataSource(null);
  // displayedColumns: string[] = ['fullName', 'email', 'mobile', 'city', 'departmentName','action'];
  displayedColumns: string[] = ['sNo', 'brand', 'model','status','dateOfPurchase','action'];
 
  searchKey: string;
 
  ngOnInit() {
      this.reloadRepotTableData();
       this.listData = this.reportData;
       this.listData = this.data // data
       this.isSearchable = true; // search
 
  }
  openEdit(rowData: any, i: number) {
    this.k = i
    this.highlight(rowData)
  }

  highlight(row) {
    console.log(row)
    this.selectedRowIndex = row.sNo;
  }

  closeEdit(rowData: any) {
    this.k = -1
    this.selectedRowIndex = -1;
  }
  deleteItem(id : number){
      this.inventryServiceService.deleteInventry(id)
        .subscribe(() => this.reloadRepotTableData());
      this.inventry = new Inventry();
      //  this.gotoList();
      this.reloadRepotTableData(); 
  }

  
 

  onSubmit() {
    //this.submitted = true;
    this.save();  
    this.reloadRepotTableData(); 
  }
  
  save() {
    console.log(this.inventry)
      this.inventryServiceService.createInventry(this.inventry)
        .subscribe(data => {
          alert(data.message);
          console.log(data);
          this.reloadRepotTableData(); // <== Fetching list again after project add
        });
      
  }

  

  reloadRepotTableData() {
    this.inventryServiceService.getDashboardData().subscribe(
      reportDataSrc => {
        this.listData = reportDataSrc;
        console.log("this.reportData:"+JSON.stringify(this.listData));

      }
    );

}

update( sNo : Number, brand: String,model: String,status: String,dateOfPurchase: String){

  console.log(sNo+"" +brand+status+model+dateOfPurchase);
}



applyFilter(filterValue: string) {
  console.log(filterValue)
  this.listData.filter = filterValue.trim().toLowerCase();
}


}
