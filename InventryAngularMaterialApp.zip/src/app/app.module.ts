import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MaterialModule } from "./material/material.module";
import { ReactiveFormsModule,FormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DatePipe } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { InventryServiceService } from './inventry-service.service';
import { InventryListComponent } from './inventries/inventry-list/inventry-list.component';
import { InventryComponent } from './inventries/inventry.component';

@NgModule({
  declarations: [
    AppComponent,
    InventryComponent,
    InventryListComponent
  ],
  imports: [
    BrowserModule,
    MaterialModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [InventryServiceService,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
