import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Inventry } from './inventry';

@Injectable({
  providedIn: 'root'
})

@Injectable({
  providedIn: 'root'
})
export class InventryServiceService {

 
constructor(private http: HttpClient) {
}

getDashboardData(): Observable<any> {
  return this.http.get<any>("http://localhost:10090/api/access/inventry/getListall");
}


createInventry(inventry: Object): Observable<any> {
  console.log(inventry);
  return this.http.post<any>("http://localhost:10090/api/access/inventry/saveinfo", inventry);
}

updateUser(inventry: Inventry): Observable<any> {
  return this.http.put<any>("http://localhost:10090/api/access/inventry/saveinfo/" + inventry.sNo, inventry);
}

getUserById(id: number): Observable<any> {
  return this.http.get<any>("http://localhost:10090/api/access/inventry/getUserById/" + id);
}
 
deleteInventry(id : number): Observable<any> {
  return this.http.get<any>("http://localhost:10090/api/access/inventry/delete/" + id);
}
}