package com.example.user.repo;
 
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.user.dto.Inventry;

@Repository
public interface UserRepository   extends JpaRepository<Inventry, Integer>{
	
	@Query( "select o from Inventry o where o.sNo = :id" )
	List<Inventry> findByInventoryIds(int id);
	
	 @Transactional
	  @Modifying
	  int deleteBysNo(int sNo);

	 @Query( "select o from Inventry o where o.sNo = :sNo and o.brand= :brand and o.model = :model " )
	Optional<Inventry> findByRecord(int sNo, String model, String brand);
	
}
